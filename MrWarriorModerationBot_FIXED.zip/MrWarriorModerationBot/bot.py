import asyncio
import json
import os
import re
from datetime import datetime, timedelta, timezone
from pathlib import Path

import discord
from discord import app_commands
from discord.ext import commands
from dotenv import load_dotenv

load_dotenv()

TOKEN = os.getenv("DISCORD_TOKEN", "").strip()
if not TOKEN:
    raise RuntimeError("DISCORD_TOKEN is missing from .env")

DATA_DIR = Path("data")
DATA_DIR.mkdir(exist_ok=True)
DATA_FILE = DATA_DIR / "guilds.json"

DEFAULT_COLOR = 0xE53935
MAX_PURGE = 100


def load_data():
    if not DATA_FILE.exists():
        return {}
    try:
        return json.loads(DATA_FILE.read_text())
    except (json.JSONDecodeError, OSError):
        return {}


def save_data(data):
    DATA_FILE.write_text(json.dumps(data, indent=2))


data = load_data()


def guild_data(guild_id: int):
    gid = str(guild_id)
    if gid not in data:
        data[gid] = {"color": DEFAULT_COLOR, "warnings": {}, "cooldowns": {}, "giveaways": {}, "polls": {}, "giveaway_counter": 0, "poll_counter": 0}
        save_data(data)
    data[gid].setdefault("color", DEFAULT_COLOR)
    data[gid].setdefault("warnings", {})
    data[gid].setdefault("cooldowns", {})
    data[gid].setdefault("giveaways", {})
    data[gid].setdefault("polls", {})
    data[gid].setdefault("giveaway_counter", 0)
    data[gid].setdefault("poll_counter", 0)
    return data[gid]


def embed(guild: discord.Guild, title: str, description: str, color=None):
    cfg = guild_data(guild.id)
    return discord.Embed(
        title=title,
        description=description,
        color=color if color is not None else cfg["color"],
        timestamp=discord.utils.utcnow(),
    )


def parse_color(value: str):
    value = value.strip().lower()
    named = {
        "red": 0xE53935, "green": 0x43A047, "blue": 0x1E88E5,
        "yellow": 0xFDD835, "orange": 0xFB8C00, "purple": 0x8E24AA,
        "pink": 0xD81B60, "cyan": 0x00ACC1, "white": 0xFFFFFF,
        "black": 0x000000, "gray": 0x757575, "grey": 0x757575,
    }
    if value in named:
        return named[value]
    value = value.removeprefix("#")
    if re.fullmatch(r"[0-9a-f]{6}", value):
        return int(value, 16)
    return None


def can_act(actor: discord.Member, target: discord.Member):
    if actor.id == target.id:
        return False, "You cannot use this command on yourself."
    if target.id == actor.guild.owner_id:
        return False, "You cannot moderate the server owner."
    if actor != actor.guild.owner and target.top_role >= actor.top_role:
        return False, "Your highest role must be above the target's highest role."
    me = actor.guild.me
    if me and target.top_role >= me.top_role:
        return False, "My highest role must be above the target's highest role."
    return True, ""


def reason_text(reason):
    return reason or "No reason provided."


class Moderation(commands.GroupCog, group_name="moderation", group_description="Moderation commands"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    @app_commands.command(name="ban", description="Ban a member.")
    @app_commands.default_permissions(ban_members=True)
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        ok, msg = can_act(interaction.user, member)
        if not ok:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Ban Failed", msg), ephemeral=True)
        try:
            await member.ban(reason=reason)
            await interaction.response.send_message(embed=embed(interaction.guild, "🔨 Member Banned", f"**{member}** was banned.\n**Reason:** {reason}"))
        except discord.Forbidden:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Ban Failed", "I do not have permission to ban this member."), ephemeral=True)

    @app_commands.command(name="unban", description="Unban a user by ID.")
    @app_commands.default_permissions(ban_members=True)
    async def unban(self, interaction: discord.Interaction, user_id: str, reason: str = "No reason provided."):
        try:
            uid = int(user_id)
            user = await self.bot.fetch_user(uid)
            await interaction.guild.unban(user, reason=reason)
            msg = f"**{user}** was unbanned.\n**Reason:** {reason}"
            await interaction.response.send_message(embed=embed(interaction.guild, "✅ Member Unbanned", msg))
        except ValueError:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unban Failed", "User ID must be a number."), ephemeral=True)
        except discord.NotFound:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unban Failed", "That user is not banned (or could not be found)."), ephemeral=True)
        except discord.Forbidden:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unban Failed", "I do not have permission to unban members."), ephemeral=True)

    @app_commands.command(name="tempban", description="Temporarily ban a member.")
    @app_commands.default_permissions(ban_members=True)
    async def tempban(self, interaction: discord.Interaction, member: discord.Member, duration: str, reason: str = "No reason provided."):
        seconds = parse_duration(duration)
        if seconds is None or seconds < 1:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Tempban Failed", "Use a duration such as `10m`, `2h`, `7d`."), ephemeral=True)
        ok, msg = can_act(interaction.user, member)
        if not ok:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Tempban Failed", msg), ephemeral=True)
        try:
            await member.ban(reason=f"Tempban {duration}: {reason}")
            await interaction.response.send_message(embed=embed(interaction.guild, "⏳ Member Tempbanned", f"**{member}** was banned for **{duration}**.\n**Reason:** {reason}"))
            await asyncio.sleep(seconds)
            try:
                await interaction.guild.unban(member, reason="Temporary ban expired.")
            except (discord.NotFound, discord.Forbidden):
                pass
        except discord.Forbidden:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Tempban Failed", "I do not have permission to ban this member."), ephemeral=True)

    @app_commands.command(name="mute", description="Timeout a member.")
    @app_commands.default_permissions(moderate_members=True)
    async def mute(self, interaction: discord.Interaction, member: discord.Member, duration: str = "10m", reason: str = "No reason provided."):
        seconds = parse_duration(duration)
        if seconds is None or seconds < 1 or seconds > 28 * 24 * 3600:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Mute Failed", "Duration must be between 1 second and 28 days (e.g. `10m`, `2h`, `1d`)."), ephemeral=True)
        ok, msg = can_act(interaction.user, member)
        if not ok:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Mute Failed", msg), ephemeral=True)
        try:
            await member.timeout(timedelta(seconds=seconds), reason=reason)
            await interaction.response.send_message(embed=embed(interaction.guild, "🔇 Member Muted", f"**{member}** was muted for **{duration}**.\n**Reason:** {reason}"))
        except discord.Forbidden:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Mute Failed", "I do not have permission to timeout this member."), ephemeral=True)

    @app_commands.command(name="unmute", description="Remove a timeout from a member.")
    @app_commands.default_permissions(moderate_members=True)
    async def unmute(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        ok, msg = can_act(interaction.user, member)
        if not ok:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unmute Failed", msg), ephemeral=True)
        try:
            await member.timeout(None, reason=reason)
            await interaction.response.send_message(embed=embed(interaction.guild, "🔊 Member Unmuted", f"**{member}** is no longer timed out.\n**Reason:** {reason}"))
        except discord.Forbidden:
            await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unmute Failed", "I do not have permission to remove timeouts."), ephemeral=True)

    @app_commands.command(name="lock", description="Lock the current channel.")
    @app_commands.default_permissions(manage_channels=True)
    async def lock(self, interaction: discord.Interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = False
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite, reason=f"Locked by {interaction.user}")
        await interaction.response.send_message(embed=embed(interaction.guild, "🔒 Channel Locked", f"{interaction.channel.mention} is now locked."))

    @app_commands.command(name="unlock", description="Unlock the current channel.")
    @app_commands.default_permissions(manage_channels=True)
    async def unlock(self, interaction: discord.Interaction):
        overwrite = interaction.channel.overwrites_for(interaction.guild.default_role)
        overwrite.send_messages = None
        await interaction.channel.set_permissions(interaction.guild.default_role, overwrite=overwrite, reason=f"Unlocked by {interaction.user}")
        await interaction.response.send_message(embed=embed(interaction.guild, "🔓 Channel Unlocked", f"{interaction.channel.mention} is now unlocked."))

    @app_commands.command(name="setcooldown", description="Set the current channel slowmode cooldown.")
    @app_commands.default_permissions(manage_channels=True)
    async def setcooldown(self, interaction: discord.Interaction, seconds: int):
        if seconds < 0 or seconds > 21600:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Cooldown Failed", "Cooldown must be between 0 and 21600 seconds."), ephemeral=True)
        await interaction.channel.edit(slowmode_delay=seconds, reason=f"Cooldown set by {interaction.user}")
        guild_data(interaction.guild.id)["cooldowns"][str(interaction.channel.id)] = seconds
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "⏱️ Cooldown Set", f"Channel cooldown set to **{seconds} seconds**."))

    @app_commands.command(name="removecooldown", description="Remove the current channel slowmode cooldown.")
    @app_commands.default_permissions(manage_channels=True)
    async def removecooldown(self, interaction: discord.Interaction):
        await interaction.channel.edit(slowmode_delay=0, reason=f"Cooldown removed by {interaction.user}")
        guild_data(interaction.guild.id)["cooldowns"].pop(str(interaction.channel.id), None)
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "⏱️ Cooldown Removed", "Channel cooldown has been removed."))

    @app_commands.command(name="snipe", description="Show the most recently deleted message.")
    @app_commands.default_permissions(manage_messages=True)
    async def snipe(self, interaction: discord.Interaction):
        message = self.bot.snipes.get(interaction.channel.id)
        if not message:
            return await interaction.response.send_message(embed=embed(interaction.guild, "🕵️ Snipe", "There is no deleted message stored for this channel."), ephemeral=True)
        desc = message["content"] or "*No text content*"
        e = embed(interaction.guild, "🕵️ Deleted Message", desc[:4000])
        e.add_field(name="Author", value=f"<@{message['author_id']}>", inline=True)
        e.add_field(name="Deleted", value=discord.utils.format_dt(message["deleted_at"], "R"), inline=True)
        await interaction.response.send_message(embed=e)

    @app_commands.command(name="purge", description="Delete messages from the current channel.")
    @app_commands.default_permissions(manage_messages=True)
    async def purge(self, interaction: discord.Interaction, amount: int):
        if amount < 1 or amount > MAX_PURGE:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Purge Failed", f"Amount must be between 1 and {MAX_PURGE}."), ephemeral=True)
        await interaction.response.defer()
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(embed=embed(interaction.guild, "🧹 Messages Purged", f"Deleted **{len(deleted)}** messages."), ephemeral=True)

    @app_commands.command(name="warn", description="Warn a member. Five warnings result in a ban.")
    @app_commands.default_permissions(manage_messages=True)
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str = "No reason provided."):
        ok, msg = can_act(interaction.user, member)
        if not ok:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Warning Failed", msg), ephemeral=True)
        gd = guild_data(interaction.guild.id)
        uid = str(member.id)
        gd["warnings"].setdefault(uid, [])
        gd["warnings"][uid].append({"reason": reason, "moderator": interaction.user.id, "timestamp": discord.utils.utcnow().isoformat()})
        count = len(gd["warnings"][uid])
        save_data(data)
        if count >= 5:
            try:
                await member.ban(reason="Automatic ban: 5 warnings reached.")
                await interaction.response.send_message(embed=embed(interaction.guild, "🔨 Auto-Ban", f"**{member}** received warning **5/5** and was automatically banned."))
            except discord.Forbidden:
                await interaction.response.send_message(embed=embed(interaction.guild, "⚠️ Warning Added", f"**{member}** now has **{count}** warnings, but I could not automatically ban them."))
        else:
            await interaction.response.send_message(embed=embed(interaction.guild, "⚠️ Warning Added", f"**{member}** received a warning.\nWarnings: **{count}/5**\n**Reason:** {reason}"))

    @app_commands.command(name="unwarn", description="Remove a warning from a member.")
    @app_commands.default_permissions(manage_messages=True)
    async def unwarn(self, interaction: discord.Interaction, member: discord.Member):
        gd = guild_data(interaction.guild.id)
        warnings = gd["warnings"].get(str(member.id), [])
        if not warnings:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Unwarn Failed", f"**{member}** has no warnings."), ephemeral=True)
        warnings.pop()
        if warnings:
            gd["warnings"][str(member.id)] = warnings
        else:
            gd["warnings"].pop(str(member.id), None)
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "✅ Warning Removed", f"Removed the latest warning from **{member}**.\nWarnings remaining: **{len(warnings)}/5**"))

    @app_commands.command(name="listwarn", description="List warnings for a member.")
    @app_commands.default_permissions(manage_messages=True)
    async def listwarn(self, interaction: discord.Interaction, member: discord.Member):
        warnings = guild_data(interaction.guild.id)["warnings"].get(str(member.id), [])
        if not warnings:
            return await interaction.response.send_message(embed=embed(interaction.guild, "📋 Warnings", f"**{member}** has no warnings."))
        lines = []
        for i, w in enumerate(warnings, 1):
            reason = w["reason"][:180]
            lines.append(f"**{i}.** {reason} — <@{w['moderator']}>")
        e = embed(interaction.guild, "📋 Warning List", "\n".join(lines))
        e.set_footer(text=f"{len(warnings)}/5 warnings")
        await interaction.response.send_message(embed=e)

def parse_event_duration(value: str):
    """Giveaway/poll durations: minutes, hours, or days only."""
    m = re.fullmatch(r"\s*(\d+)\s*([mhd])\s*", value.lower())
    if not m:
        return None
    n = int(m.group(1))
    if n < 1:
        return None
    return n * {"m": 60, "h": 3600, "d": 86400}[m.group(2)]


def duration_left(end_timestamp: float):
    remaining = max(0, int(end_timestamp - discord.utils.utcnow().timestamp()))
    d, remaining = divmod(remaining, 86400)
    h, remaining = divmod(remaining, 3600)
    m, sec = divmod(remaining, 60)
    parts = []
    if d:
        parts.append(f"{d}d")
    if h or d:
        parts.append(f"{h}h")
    if m or h or d:
        parts.append(f"{m}m")
    parts.append(f"{sec}s")
    return " ".join(parts)


def format_duration(seconds: int):
    d, rem = divmod(seconds, 86400)
    h, rem = divmod(rem, 3600)
    m, sec = divmod(rem, 60)
    if d:
        return f"{d}d" + (f" {h}h" if h else "")
    if h:
        return f"{h}h" + (f" {m}m" if m else "")
    if m:
        return f"{m}m"
    return f"{sec}s"


POLL_BAR_LENGTH = 15
MAX_POLL_OPTIONS = 20
DOT = "🟡"


def progress_bar(pct: float, length: int = POLL_BAR_LENGTH):
    filled = max(0, min(length, round(pct / 100 * length)))
    return "█" * filled + "░" * (length - filled)


class GiveawayView(discord.ui.View):
    def __init__(self, bot, guild_id: int, giveaway_id: str):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id
        self.giveaway_id = giveaway_id
        button = discord.ui.Button(
            label="Enter Giveaway",
            emoji="🎉",
            style=discord.ButtonStyle.primary,
            custom_id=f"mrwarrior:giveaway:{guild_id}:{giveaway_id}",
        )
        button.callback = self.enter
        self.add_item(button)

    async def enter(self, interaction: discord.Interaction):
        gd = guild_data(self.guild_id)
        g = gd["giveaways"].get(self.giveaway_id)
        if not g or g.get("status") != "ongoing":
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Giveaway Closed", "This giveaway is no longer active."), ephemeral=True)

        if g.get("required_role"):
            role = interaction.guild.get_role(int(g["required_role"]))
            if role and role not in interaction.user.roles:
                return await interaction.response.send_message(
                    embed=embed(interaction.guild, "❌ Entry Restricted", f"You need the {role.mention} role to enter."),
                    ephemeral=True,
                )
        if g.get("restricted_role"):
            role = interaction.guild.get_role(int(g["restricted_role"]))
            if role and role in interaction.user.roles:
                return await interaction.response.send_message(
                    embed=embed(interaction.guild, "❌ Entry Restricted", "Members with the restricted role cannot enter this giveaway."),
                    ephemeral=True,
                )

        entries = g.setdefault("entries", [])
        uid = str(interaction.user.id)
        if uid in entries:
            entries.remove(uid)
            message = "You have left the giveaway."
        else:
            entries.append(uid)
            message = "You have entered the giveaway! 🎉"
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "🎉 Giveaway", message), ephemeral=True)


class PollView(discord.ui.View):
    def __init__(self, bot, guild_id: int, poll_id: str, options):
        super().__init__(timeout=None)
        self.bot = bot
        self.guild_id = guild_id
        self.poll_id = poll_id
        self.options = options
        for idx, _option in enumerate(options[:MAX_POLL_OPTIONS]):
            button = discord.ui.Button(
                label=f"Option {idx + 1}",
                style=discord.ButtonStyle.primary,
                custom_id=f"mrwarrior:poll:{guild_id}:{poll_id}:{idx}",
                row=idx // 5,
            )
            button.callback = self._make_callback(idx)
            self.add_item(button)

    def _make_callback(self, idx):
        async def callback(interaction: discord.Interaction):
            gd = guild_data(self.guild_id)
            p = gd["polls"].get(self.poll_id)
            if not p or p.get("status") != "ongoing":
                return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Poll Closed", "This poll is no longer active."), ephemeral=True)
            votes = p.setdefault("votes", {})
            uid = str(interaction.user.id)
            old = votes.get(uid)
            if old is not None and old == idx:
                votes.pop(uid, None)
                msg = "Your vote was removed."
            else:
                votes[uid] = idx
                msg = f"Your vote is now **Option {idx + 1}**: {p['options'][idx]}"
            save_data(data)
            # Refresh the poll message so the bars update live, then confirm privately.
            await interaction.response.edit_message(embed=poll_embed(interaction.guild, p))
            await interaction.followup.send(embed=embed(interaction.guild, "🗳️ Vote Recorded", msg), ephemeral=True)
        return callback


def giveaway_ended_ts(g):
    raw = g.get("ended_at")
    if raw:
        try:
            return datetime.fromisoformat(raw).timestamp()
        except ValueError:
            pass
    return float(g.get("end_at", 0))


def giveaway_content(g):
    status = g.get("status", "ongoing")
    if status == "ongoing":
        return "## 🎉 Giveaway 🎉"
    if status == "cancelled":
        return "## 🚫 Giveaway Cancelled 🚫"
    return "## 🎉 Giveaway Ended 🎉"


def giveaway_embed(guild, g, ended=False):
    status = g.get("status", "ongoing")
    e = discord.Embed(title=f"🎁 {g['prize']} 🎁"[:256], color=guild_data(guild.id)["color"])
    lines = []
    if status == "ongoing":
        end_ts = int(g["end_at"])
        lines.append(f"{DOT} Ends: <t:{end_ts}:R>")
        e.set_footer(text="Ends at")
    else:
        end_ts = int(giveaway_ended_ts(g))
        word = "Cancelled" if status == "cancelled" else "Ended at"
        lines.append(f"{DOT} {word} <t:{end_ts}:R>")
        e.set_footer(text="Cancelled" if status == "cancelled" else "Ended")
    e.timestamp = datetime.fromtimestamp(end_ts, tz=timezone.utc)
    if g.get("host_id"):
        lines.append(f"{DOT} Hosted by <@{g['host_id']}>")
    if g.get("required_role"):
        lines.append(f"{DOT} Required role: <@&{g['required_role']}>")
    if g.get("restricted_role"):
        lines.append(f"{DOT} Restricted role: <@&{g['restricted_role']}>")
    if status == "ended":
        winners = g.get("winners", [])
        lines.append("")
        lines.append(f"{DOT} Winners: " + (" ".join(f"<@{x}>" for x in winners) if winners else "No valid entrants"))
    e.description = "\n".join(lines)
    return e


def poll_embed(guild, p, ended=False):
    options = p["options"]
    counts = [0] * len(options)
    for idx in p.get("votes", {}).values():
        if isinstance(idx, int) and 0 <= idx < len(counts):
            counts[idx] += 1
    total = sum(counts)
    blocks = []
    for i, option in enumerate(options):
        pct = (counts[i] / total * 100) if total else 0
        blocks.append(f"**{option}**\n{progress_bar(pct)} | {pct:.2f}% ({counts[i]})")
    desc = f"{p['description']}\n\n" + "\n\n".join(blocks)
    e = discord.Embed(title=p["title"][:256], description=desc[:4096], color=guild_data(guild.id)["color"])
    if p.get("author_id"):
        e.add_field(name="Poll author", value=f"<@{p['author_id']}>", inline=False)
    is_ended = ended or p.get("status") == "ended"
    e.set_footer(text=f"Poll ID: {p['id']} • {'Ended' if is_ended else 'Ends'}")
    e.timestamp = datetime.fromtimestamp(int(p.get("end_at", 0)), tz=timezone.utc)
    return e


class Giveaway(commands.GroupCog, group_name="giveaway", group_description="Giveaway commands"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    @app_commands.command(name="start", description="Start a giveaway.")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(prize="Giveaway prize", duration="Duration: 1m, 1h, or 1d",
                           required_role="Only members with this role can enter",
                           restricted_role="Members with this role cannot enter", channel="Channel for the giveaway")
    async def start(self, interaction: discord.Interaction, prize: str, duration: str,
                    required_role: discord.Role = None, restricted_role: discord.Role = None,
                    channel: discord.TextChannel = None):
        seconds = parse_event_duration(duration)
        if seconds is None:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Invalid Duration", "Use `1m`, `1h`, or `1d`."), ephemeral=True)
        target = channel or interaction.channel
        gd = guild_data(interaction.guild.id)
        gd["giveaway_counter"] += 1
        gid = str(gd["giveaway_counter"])
        now = discord.utils.utcnow()
        g = {
            "id": gid, "prize": prize, "duration": seconds, "end_at": (now.timestamp() + seconds),
            "status": "ongoing", "entries": [], "winners": [], "message_id": None,
            "channel_id": target.id, "required_role": str(required_role.id) if required_role else None,
            "restricted_role": str(restricted_role.id) if restricted_role else None,
            "host_id": str(interaction.user.id),
            "created_at": now.isoformat(),
        }
        gd["giveaways"][gid] = g
        save_data(data)
        msg = await target.send(content=giveaway_content(g), embed=giveaway_embed(interaction.guild, g), view=GiveawayView(self.bot, interaction.guild.id, gid))
        g["message_id"] = msg.id
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "🎉 Giveaway Started", f"Giveaway `{gid}` started in {target.mention}."), ephemeral=True)

    async def _get_giveaway(self, interaction, gid=None):
        gs = guild_data(interaction.guild.id)["giveaways"]
        active = [g for g in gs.values() if g.get("status") == "ongoing"]
        if gid:
            g = gs.get(str(gid))
            if not g:
                return None, "Giveaway not found."
            return g, None
        if not active:
            return None, "There are no ongoing giveaways."
        return max(active, key=lambda x: x.get("created_at", "")), None

    @app_commands.command(name="end", description="End a giveaway and select winner(s).")
    @app_commands.default_permissions(manage_guild=True)
    async def end(self, interaction: discord.Interaction, giveaway_id: str = None):
        g, err = await self._get_giveaway(interaction, giveaway_id)
        if err:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Giveaway", err), ephemeral=True)
        await finish_giveaway(interaction.guild, g, cancelled=False)
        await interaction.response.send_message(embed=embed(interaction.guild, "🏁 Giveaway Ended", f"Giveaway `{g['id']}` has ended."), ephemeral=True)

    @app_commands.command(name="reroll", description="Reroll the winner of a completed giveaway.")
    @app_commands.default_permissions(manage_guild=True)
    async def reroll(self, interaction: discord.Interaction, giveaway_id: str = None):
        import random
        gs = guild_data(interaction.guild.id)["giveaways"]
        candidates = [g for g in gs.values() if g.get("status") == "ended" and g.get("entries")]
        if giveaway_id:
            candidates = [gs.get(str(giveaway_id))] if gs.get(str(giveaway_id)) else []
        if not candidates:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Reroll Failed", "No completed giveaway with entries was found."), ephemeral=True)
        g = max(candidates, key=lambda x: x.get("ended_at", x.get("created_at", "")))
        previous = set(g.get("winners", []))
        pool = [x for x in g.get("entries", []) if x not in previous] or g.get("entries", [])
        winner = random.choice(pool)
        g["winners"] = [winner]
        save_data(data)
        await update_giveaway_message(interaction.guild, g)
        await interaction.response.send_message(embed=embed(interaction.guild, "🔄 Giveaway Rerolled", f"New winner for giveaway `{g['id']}`: <@{winner}>"))

    @app_commands.command(name="restart", description="Restart an ended giveaway with a fresh timer and entries.")
    @app_commands.default_permissions(manage_guild=True)
    async def restart(self, interaction: discord.Interaction, giveaway_id: str = None):
        g, err = await self._get_giveaway(interaction, giveaway_id)
        if err:
            gs = guild_data(interaction.guild.id)["giveaways"]
            ended = [x for x in gs.values() if x.get("status") == "ended"]
            if not ended:
                return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Restart Failed", "No giveaway was found."), ephemeral=True)
            g = max(ended, key=lambda x: x.get("ended_at", x.get("created_at", "")))
        g["status"] = "ongoing"
        g["entries"] = []
        g["winners"] = []
        g["end_at"] = discord.utils.utcnow().timestamp() + int(g["duration"])
        g.pop("ended_at", None)
        save_data(data)
        await update_giveaway_message(interaction.guild, g)
        await interaction.response.send_message(embed=embed(interaction.guild, "🔄 Giveaway Restarted", f"Giveaway `{g['id']}` is running again."))

    @app_commands.command(name="cancel", description="Cancel all ongoing giveaways.")
    @app_commands.default_permissions(manage_guild=True)
    async def cancel(self, interaction: discord.Interaction):
        gs = guild_data(interaction.guild.id)["giveaways"]
        active = [g for g in gs.values() if g.get("status") == "ongoing"]
        if not active:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Giveaway", "There are no ongoing giveaways."), ephemeral=True)
        for g in active:
            g["status"] = "cancelled"
            g["ended_at"] = discord.utils.utcnow().isoformat()
            await update_giveaway_message(interaction.guild, g)
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "🛑 Giveaways Cancelled", f"Cancelled **{len(active)}** ongoing giveaway(s)."))

    @app_commands.command(name="list", description="List ongoing and ended giveaways.")
    async def list(self, interaction: discord.Interaction):
        gs = list(guild_data(interaction.guild.id)["giveaways"].values())
        if not gs:
            return await interaction.response.send_message(embed=embed(interaction.guild, "📋 Giveaways", "No giveaways found."), ephemeral=True)
        active = [g for g in gs if g.get("status") == "ongoing"]
        ended = [g for g in gs if g.get("status") in ("ended", "cancelled")]
        lines = []
        for g in active[:15]:
            lines.append(
                f"🟢 `{g['id']}` — **{g['prize']}**\n"
                f"   Duration left: **{duration_left(g['end_at'])}** • Entries: **{len(g.get('entries', []))}**"
            )
        for g in ended[-15:][::-1]:
            winners = " ".join(f"<@{x}>" for x in g.get("winners", [])) or "No winner"
            lines.append(
                f"⚪ `{g['id']}` — **{g['prize']}** — {g['status']}\n"
                f"   Entries: **{len(g.get('entries', []))}** • Winner(s): {winners}"
            )
        await interaction.response.send_message(embed=embed(interaction.guild, "📋 Giveaway List", "\n".join(lines)[:4090]))


async def update_giveaway_message(guild, g):
    channel = guild.get_channel(int(g["channel_id"]))
    if not channel:
        return
    try:
        msg = await channel.fetch_message(int(g["message_id"])) if g.get("message_id") else None
        if msg:
            view = GiveawayView(bot, guild.id, g["id"]) if g.get("status") == "ongoing" else None
            await msg.edit(content=giveaway_content(g), embed=giveaway_embed(guild, g), view=view)
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        pass


async def finish_giveaway(guild, g, cancelled=False):
    import random
    if g.get("status") != "ongoing":
        return
    g["status"] = "cancelled" if cancelled else "ended"
    g["ended_at"] = discord.utils.utcnow().isoformat()
    if not cancelled:
        entries = g.get("entries", [])
        g["winners"] = [random.choice(entries)] if entries else []
    save_data(data)
    await update_giveaway_message(guild, g)
    if not cancelled:
        await announce_giveaway_result(guild, g)


async def announce_giveaway_result(guild, g):
    channel = guild.get_channel(int(g["channel_id"]))
    if not channel:
        return
    host = f", Hosted by <@{g['host_id']}>" if g.get("host_id") else ""
    winners = g.get("winners", [])
    if winners:
        text = f"🎉 Congrats {', '.join(f'<@{w}>' for w in winners)}, You have won **{g['prize']}**!{host}"
    else:
        text = f"😔 No valid entrants for **{g['prize']}**.{host}"
    reference = None
    if g.get("message_id"):
        reference = discord.MessageReference(message_id=int(g["message_id"]), channel_id=channel.id, fail_if_not_exists=False)
    try:
        await channel.send(text, reference=reference, allowed_mentions=discord.AllowedMentions(users=True, roles=False, everyone=False))
    except (discord.Forbidden, discord.HTTPException):
        pass


class Poll(commands.GroupCog, group_name="poll", group_description="Poll commands"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    @app_commands.command(name="create", description="Create a poll (up to 20 options).")
    @app_commands.default_permissions(manage_guild=True)
    @app_commands.describe(title="Poll title", description="Poll question / description", duration="Duration: 1m, 1h, or 1d",
                           option1="Option 1", option2="Option 2", channel="Channel for the poll",
                           **{f"option{i}": f"Option {i}" for i in range(3, 21)})
    async def create(self, interaction: discord.Interaction, title: str, description: str, duration: str,
                     option1: str, option2: str,
                     channel: discord.TextChannel = None,
                     option3: str = None, option4: str = None, option5: str = None, option6: str = None,
                     option7: str = None, option8: str = None, option9: str = None, option10: str = None,
                     option11: str = None, option12: str = None, option13: str = None, option14: str = None,
                     option15: str = None, option16: str = None, option17: str = None, option18: str = None,
                     option19: str = None, option20: str = None):
        seconds = parse_event_duration(duration)
        if seconds is None:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Invalid Duration", "Use `1m`, `1h`, or `1d`."), ephemeral=True)
        raw = [option1, option2, option3, option4, option5, option6, option7, option8, option9, option10,
               option11, option12, option13, option14, option15, option16, option17, option18, option19, option20]
        options = [x.strip()[:100] for x in raw if x and x.strip()]
        if len(options) < 2:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Poll", "At least two options are required."), ephemeral=True)
        target = channel or interaction.channel
        gd = guild_data(interaction.guild.id)
        gd["poll_counter"] += 1
        pid = str(gd["poll_counter"])
        now = discord.utils.utcnow()
        p = {
            "id": pid, "title": title.strip()[:256], "description": description.strip()[:1000], "options": options,
            "duration": seconds, "end_at": now.timestamp() + seconds, "status": "ongoing", "votes": {},
            "message_id": None, "channel_id": target.id, "author_id": str(interaction.user.id),
            "created_at": now.isoformat(),
        }
        gd["polls"][pid] = p
        save_data(data)
        msg = await target.send(embed=poll_embed(interaction.guild, p), view=PollView(self.bot, interaction.guild.id, pid, options))
        p["message_id"] = msg.id
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "🗳️ Poll Created", f"Poll `{pid}` created in {target.mention}."), ephemeral=True)

    async def _latest_ended(self, interaction):
        ps = [p for p in guild_data(interaction.guild.id)["polls"].values() if p.get("status") == "ended"]
        return max(ps, key=lambda x: x.get("ended_at", x.get("created_at", ""))) if ps else None

    @app_commands.command(name="end", description="End a poll.")
    @app_commands.default_permissions(manage_guild=True)
    async def end(self, interaction: discord.Interaction, poll_id: str = None):
        ps = guild_data(interaction.guild.id)["polls"]
        if poll_id:
            p = ps.get(str(poll_id))
        else:
            active = [x for x in ps.values() if x.get("status") == "ongoing"]
            p = max(active, key=lambda x: x.get("created_at", "")) if active else None
        if not p:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Poll", "No ongoing poll was found."), ephemeral=True)
        p["status"] = "ended"
        p["ended_at"] = discord.utils.utcnow().isoformat()
        save_data(data)
        await update_poll_message(interaction.guild, p)
        await interaction.response.send_message(embed=embed(interaction.guild, "🏁 Poll Ended", f"Poll `{p['id']}` has ended."), ephemeral=True)

    @app_commands.command(name="restart", description="Restart the last ended poll.")
    @app_commands.default_permissions(manage_guild=True)
    async def restart(self, interaction: discord.Interaction):
        p = await self._latest_ended(interaction)
        if not p:
            return await interaction.response.send_message(embed=embed(interaction.guild, "❌ Poll Restart", "No ended poll was found."), ephemeral=True)
        p["status"] = "ongoing"
        p["votes"] = {}
        p["end_at"] = discord.utils.utcnow().timestamp() + int(p["duration"])
        p.pop("ended_at", None)
        save_data(data)
        await update_poll_message(interaction.guild, p)
        await interaction.response.send_message(embed=embed(interaction.guild, "🔄 Poll Restarted", f"Poll `{p['id']}` has been restarted."))

    @app_commands.command(name="list", description="List current and past polls with results.")
    async def list(self, interaction: discord.Interaction):
        ps = list(guild_data(interaction.guild.id)["polls"].values())
        if not ps:
            return await interaction.response.send_message(embed=embed(interaction.guild, "📋 Polls", "No polls found."), ephemeral=True)
        active = [p for p in ps if p.get("status") == "ongoing"]
        ended = [p for p in ps if p.get("status") == "ended"]
        lines = []
        for p in active[-10:][::-1]:
            option_text = " | ".join(f"{i+1}. {x}" for i, x in enumerate(p["options"]))
            lines.append(
                f"🟢 `{p['id']}` — **{p['title']}**\n"
                f"   {p['description'][:180]}\n"
                f"   Options: {option_text[:650]}\n"
                f"   Duration left: **{duration_left(p['end_at'])}**"
            )
        for p in ended[-10:][::-1]:
            counts = [0] * len(p["options"])
            for idx in p.get("votes", {}).values():
                if isinstance(idx, int) and 0 <= idx < len(counts):
                    counts[idx] += 1
            results = " | ".join(f"{i+1}. {p['options'][i]}: {counts[i]}" for i in range(len(p["options"])))
            lines.append(
                f"⚪ `{p['id']}` — **{p['title']}**\n"
                f"   {p['description'][:180]}\n"
                f"   Results: {results[:650]}\n"
                f"   Total votes: **{sum(counts)}**"
            )
        await interaction.response.send_message(embed=embed(interaction.guild, "📋 Poll List", "\n".join(lines)[:4090]))


async def update_poll_message(guild, p):
    channel = guild.get_channel(int(p["channel_id"]))
    if not channel:
        return
    try:
        msg = await channel.fetch_message(int(p["message_id"])) if p.get("message_id") else None
        if msg:
            view = PollView(bot, guild.id, p["id"], p["options"]) if p.get("status") == "ongoing" else None
            await msg.edit(embed=poll_embed(guild, p), view=view)
    except (discord.NotFound, discord.Forbidden, discord.HTTPException):
        pass


async def expire_events():
    while True:
        now = discord.utils.utcnow().timestamp()
        changed = False
        for gid, gd in list(data.items()):
            guild = bot.get_guild(int(gid))
            if not guild:
                continue
            for g in gd.get("giveaways", {}).values():
                if g.get("status") == "ongoing" and g.get("end_at", 0) <= now:
                    await finish_giveaway(guild, g)
                    changed = True
            for p in gd.get("polls", {}).values():
                if p.get("status") == "ongoing" and p.get("end_at", 0) <= now:
                    p["status"] = "ended"
                    p["ended_at"] = discord.utils.utcnow().isoformat()
                    await update_poll_message(guild, p)
                    changed = True
        if changed:
            save_data(data)
        await asyncio.sleep(5)


def parse_duration(value: str):
    m = re.fullmatch(r"\s*(\d+)\s*([smhdw])\s*", value.lower())
    if not m:
        return None
    n = int(m.group(1))
    return n * {"s": 1, "m": 60, "h": 3600, "d": 86400, "w": 604800}[m.group(2)]


class Global(commands.GroupCog, group_name="global", group_description="Global bot settings"):
    def __init__(self, bot):
        self.bot = bot
        super().__init__()

    @app_commands.command(name="color", description="Change the embed outline color.")
    @app_commands.default_permissions(manage_guild=True)
    async def color(self, interaction: discord.Interaction, color: str):
        parsed = parse_color(color)
        if parsed is None:
            return await interaction.response.send_message(
                embed=embed(interaction.guild, "❌ Invalid Color", "Use a named color such as `red` or a hex value such as `#ff0000`."),
                ephemeral=True,
            )
        gd = guild_data(interaction.guild.id)
        gd["color"] = parsed
        save_data(data)
        await interaction.response.send_message(embed=embed(interaction.guild, "🎨 Embed Color Updated", f"Embed color changed to **{color}**."))


class ModerationBot(commands.Bot):
    def __init__(self):
        intents = discord.Intents.default()
        intents.guilds = True
        intents.members = True
        intents.messages = True
        intents.message_content = True
        super().__init__(command_prefix="!", intents=intents)
        self.snipes = {}

    async def setup_hook(self):
        await self.add_cog(Moderation(self))
        await self.add_cog(Global(self))
        await self.add_cog(Giveaway(self))
        await self.add_cog(Poll(self))
        self.tree.add_command(ping_command)
        self.tree.add_command(help_command)

        # Restore persistent buttons after a restart.
        for gid, gd in data.items():
            for g in gd.get("giveaways", {}).values():
                if g.get("status") == "ongoing":
                    self.add_view(GiveawayView(self, int(gid), g["id"]))
            for p in gd.get("polls", {}).values():
                if p.get("status") == "ongoing":
                    self.add_view(PollView(self, int(gid), p["id"], p.get("options", [])))

        await self.tree.sync()
        if not hasattr(self, "expiry_task"):
            self.expiry_task = asyncio.create_task(expire_events())

    async def on_ready(self):
        print(f"Logged in as {self.user} | {self.user.id}")
        print(f"Connected to {len(self.guilds)} guild(s).")

    async def on_message_delete(self, message: discord.Message):
        if message.guild and not message.author.bot:
            self.snipes[message.channel.id] = {
                "content": message.content,
                "author_id": message.author.id,
                "deleted_at": discord.utils.utcnow(),
            }



@app_commands.command(name="ping", description="Show bot latency.")
async def ping_command(interaction: discord.Interaction):
    await interaction.response.send_message(
        embed=embed(interaction.guild, "🏓 Pong", f"Latency: **{round(interaction.client.latency * 1000)}ms**")
    )


@app_commands.command(name="help", description="Show all bot commands.")
async def help_command(interaction: discord.Interaction):
    e = embed(
        interaction.guild,
        "📚 MrWarrior Moderation Help",
        "**Moderation**\n"
        "`/moderation ban` • `/moderation unban` • `/moderation tempban`\n"
        "`/moderation mute` • `/moderation unmute` • `/moderation lock` • `/moderation unlock`\n"
        "`/moderation setcooldown` • `/moderation removecooldown` • `/moderation purge`\n"
        "`/moderation snipe` • `/moderation warn` • `/moderation unwarn` • `/moderation listwarn`\n\n"
        "**General**\n"
        "`/ping` — Bot latency\n"
        "`/help` — This help menu\n"
        "`/global color` — Change embed color\n\n"
        "**Giveaways**\n"
        "`/giveaway start` — Start a giveaway\n"
        "`/giveaway end` — End a giveaway early\n"
        "`/giveaway reroll` — Reroll a completed giveaway\n"
        "`/giveaway restart` — Restart a giveaway\n"
        "`/giveaway cancel` — Cancel ongoing giveaways\n"
        "`/giveaway list` — List active and ended giveaways\n\n"
        "**Polls**\n"
        "`/poll create` — Create a poll (up to 20 options)\n"
        "`/poll end` — End a poll\n"
        "`/poll restart` — Restart the last ended poll\n"
        "`/poll list` — List current polls and past results"
    )
    await interaction.response.send_message(embed=e)



bot = ModerationBot()
bot.run(TOKEN)
