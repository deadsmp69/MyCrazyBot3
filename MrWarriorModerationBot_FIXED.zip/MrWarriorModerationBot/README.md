# Moderation Discord Bot

Python `discord.py` moderation bot for Ubuntu 22.04/24.04 without Docker.

## Slash command layout

- `/moderation ban`
- `/moderation unban`
- `/moderation tempban`
- `/moderation mute`
- `/moderation unmute`
- `/moderation lock`
- `/moderation unlock`
- `/moderation setcooldown`
- `/moderation removecooldown`
- `/moderation snipe`
- `/moderation purge`
- `/moderation warn`
- `/moderation unwarn`
- `/moderation listwarn`
- `/moderation ping`
- `/moderation help`
- `/global color`

Warnings are stored per guild. At 5 warnings the bot attempts an automatic ban.

## Color

`/global color color:red`

or

`/global color color:#ff0000`

The setting is saved per server.

## Notes

Tempbans are scheduled in the running process. For production persistence across bot restarts, a database-backed job queue should be added later.

The bot uses Discord's built-in timeout for mute, with a maximum duration of 28 days.

Never commit `.env` to GitHub.
