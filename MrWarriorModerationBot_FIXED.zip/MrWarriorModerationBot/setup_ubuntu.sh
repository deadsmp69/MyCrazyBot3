#!/usr/bin/env bash
set -e
apt update
apt install -y python3 python3-venv python3-pip git
python3 -m venv venv
./venv/bin/pip install --upgrade pip
./venv/bin/pip install -r requirements.txt
echo
echo "Install complete."
echo "Create .env from .env.example, then run: ./venv/bin/python bot.py"
